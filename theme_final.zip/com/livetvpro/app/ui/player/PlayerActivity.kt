package com.livetvpro.app.ui.player

import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.util.Rational
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toAndroidRect
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.HttpMediaDrmCallback
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import com.livetvpro.app.R
import com.livetvpro.app.data.models.Channel
import com.livetvpro.app.data.models.LiveEvent
import com.livetvpro.app.data.models.LiveEventLink
import com.livetvpro.app.ui.player.PlayerStreamHelper
import com.livetvpro.app.ui.player.StreamInfo
import com.livetvpro.app.ui.player.compose.PlayerControls
import com.livetvpro.app.ui.player.compose.PlayerControlsState
import com.livetvpro.app.ui.player.compose.GestureState
import com.livetvpro.app.ui.player.compose.PlayerScreen
import com.livetvpro.app.ui.player.compose.RelatedContentState
import com.livetvpro.app.ui.player.compose.LandscapeLinksRow
import com.livetvpro.app.ui.player.dialogs.FloatingPlayerDialog
import com.livetvpro.app.ui.player.settings.PlayerSettingsDialog
import com.livetvpro.app.ui.theme.AppThemeContent
import com.livetvpro.app.data.local.ThemeManager
import com.livetvpro.app.utils.DeviceUtils
import com.livetvpro.app.ui.player.ChannelListCache
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID
import android.annotation.SuppressLint
import android.graphics.Rect
import androidx.compose.runtime.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.ViewCompositionStrategy
import android.media.AudioManager
import androidx.recyclerview.widget.RecyclerView

@UnstableApi
@AndroidEntryPoint
class PlayerActivity : BasePlayerActivity() {
    private val relatedContentState = mutableStateOf<RelatedContentState>(RelatedContentState.Hidden)
    private val linksState          = mutableStateOf<List<LiveEventLink>>(emptyList())
    private val selectedLinkState   = mutableStateOf(0)
    private val messageBannerText   = mutableStateOf("")
    private val messageBannerUrl    = mutableStateOf("")
    private val showSettingsDialog  = mutableStateOf(false)
    private val showFloatingDialog  = mutableStateOf(false)
    internal val errorMessage        = mutableStateOf("")
    private var relatedChannels = listOf<Channel>()

    private val mainHandler = Handler(Looper.getMainLooper())
    internal val viewModel: PlayerViewModel by viewModels()
    private var player: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var playerListener: Player.Listener? = null

    @javax.inject.Inject
    override lateinit var themeManager: ThemeManager

    @javax.inject.Inject
    lateinit var preferencesManager: com.livetvpro.app.data.local.PreferencesManager

    @javax.inject.Inject
    lateinit var listenerManager: com.livetvpro.app.utils.NativeListenerManager
    private lateinit var playerViewRef: androidx.media3.ui.PlayerView
    override lateinit var playerContainer: androidx.constraintlayout.widget.ConstraintLayout

    private val controlsState = PlayerControlsState()
    private var showChannelList = mutableStateOf(false)
    internal var gestureVolume: Int = 100
    internal var gestureBrightness: Int = 0

    private var isInPipMode = false
    private var isEnteringPip = false
    private var isMuted by mutableStateOf(false)
    internal val skipMs = 10_000L

    private var networkPortraitResizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
    private var networkLandscapeResizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
    private var resizeModesRestoredFromState = false

    private var pipReceiver: BroadcastReceiver? = null
    private var screenOffReceiver: BroadcastReceiver? = null
    private var isScreenOff = false
    private var wasLockedBeforePip = false
    private var isShowingSettingsDialog = false
    private var pipRect: Rect? = null
    val isPipSupported by lazy {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            false
        } else {
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        }
    }

    internal var contentType: ContentType = ContentType.CHANNEL
    private var channelNumberInput: String = ""
    private val channelNumberHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val channelNumberRunnable = Runnable { navigateToChannelByNumber() }
    private val showChannelOverlayState = mutableStateOf<Pair<String, String>?>(null)
    private val overlayHideRunnable = Runnable { showChannelOverlayState.value = null }
    private var pendingChannelIndex: Int = -1
    private var pendingChannelDirection: Int = 0
    private var pendingChannelNumber: Int = -1
    private var channelData: Channel? = null
    private var eventData: LiveEvent? = null
    internal var allEventLinks = listOf<LiveEventLink>()
    internal var currentLinkIndex = 0
    internal var contentId: String = ""
    internal var contentName: String by mutableStateOf("")
    private var streamUrl: String = ""
    private var intentCategoryId: String? = null
    private var intentSelectedGroup: String? = null
    private var intentIsSports: Boolean = false

    enum class ContentType {
        CHANNEL, EVENT, NETWORK_STREAM
    }

    companion object {
        private const val EXTRA_CHANNEL = "extra_channel"
        private const val EXTRA_EVENT = "extra_event"
        private const val EXTRA_SELECTED_LINK_INDEX = "extra_selected_link_index"
        private const val EXTRA_RELATED_CHANNELS_KEY = "extra_related_channels_key"
        private const val EXTRA_CATEGORY_ID = "extra_category_id"
        private const val EXTRA_IS_SPORTS = "extra_is_sports"
        private const val EXTRA_CHANNEL_LIST_KEY = "extra_channel_list_key"
        private const val EXTRA_SELECTED_GROUP = "extra_selected_group"

        private const val ACTION_MEDIA_CONTROL = "com.livetvpro.app.MEDIA_CONTROL"
        private const val EXTRA_CONTROL_TYPE = "control_type"
        private const val CONTROL_TYPE_PLAY = 1
        private const val CONTROL_TYPE_PAUSE = 2
        private const val CONTROL_TYPE_REWIND = 3
        private const val CONTROL_TYPE_FORWARD = 4
        private const val CONTROL_TYPE_PREV_CHANNEL = 5
        private const val CONTROL_TYPE_NEXT_CHANNEL = 6

        private const val PIP_INTENTS_FILTER = "com.livetvpro.app.PIP_CONTROL"
        private const val PIP_INTENT_ACTION = "pip_action"
        private const val PIP_PLAY = 1
        private const val PIP_PAUSE = 2
        private const val PIP_FR = 3
        private const val PIP_FF = 4

        var isInPip: Boolean = false

        fun startWithChannel(context: Context, channel: Channel, linkIndex: Int = -1, relatedChannels: ArrayList<Channel>? = null, categoryId: String? = null, selectedGroup: String? = null, isSports: Boolean = false, channelList: ArrayList<Channel>? = null, channelListCacheKey: String? = null) {
            val intent = Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_CHANNEL, channel as Parcelable)
                putExtra(EXTRA_SELECTED_LINK_INDEX, linkIndex)
                relatedChannels?.let {
                    val key = "related_${channel.id}"
                    ChannelListCache.put(key, it)
                    putExtra(EXTRA_RELATED_CHANNELS_KEY, key)
                }
                categoryId?.let { putExtra(EXTRA_CATEGORY_ID, it) }
                selectedGroup?.let { putExtra(EXTRA_SELECTED_GROUP, it) }
                putExtra(EXTRA_IS_SPORTS, isSports)
                val key = channelListCacheKey ?: channelList?.let { list ->
                    val k = categoryId ?: channel.categoryId.takeIf { it.isNotEmpty() } ?: channel.id
                    ChannelListCache.put(k, list)
                    k
                }
                key?.let { putExtra(EXTRA_CHANNEL_LIST_KEY, it) }
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                if (isInPip) addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(intent)
            if (context is android.app.Activity) {
                context.overridePendingTransition(0, 0)
            }
        }

        fun startWithEvent(context: Context, event: LiveEvent, linkIndex: Int = -1) {
            val intent = Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_EVENT, event as Parcelable)
                putExtra(EXTRA_SELECTED_LINK_INDEX, linkIndex)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                if (isInPip) addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(intent)
            if (context is android.app.Activity) {
                context.overridePendingTransition(0, 0)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNewIntent(intent)
    }

    private fun handleNewIntent(intent: Intent) {
        cancelNumberInput()
        showChannelList.value = false

        val newChannel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CHANNEL, Channel::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_CHANNEL)
        }
        val newEvent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_EVENT, LiveEvent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_EVENT)
        }
        val linkIndex = intent.getIntExtra(EXTRA_SELECTED_LINK_INDEX, -1)

        when {
            newChannel != null -> switchToChannel(newChannel, linkIndex)
            newEvent != null   -> switchToEventFromLiveEvent(newEvent, linkIndex)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        themeManager.registerActivityContext(this)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            postponeEnterTransition()
        }

        val binding = androidx.compose.ui.platform.ComposeView(this).also { composeRoot ->
            composeRoot.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            composeRoot.setContent {
                AppThemeContent(themeManager) {
                    PlayerActivityRoot(
                        activity = this,
                        controlsState = controlsState,
                        showChannelList = showChannelList,
                        isMuted = isMuted,
                        relatedContentState = relatedContentState.value,
                        links = linksState.value,
                        selectedLinkIndex = selectedLinkState.value,
                        messageBanner = messageBannerText.value,
                        messageBannerUrl = messageBannerUrl.value,
                        errorMessage = errorMessage.value,
                        showSettingsDialog = showSettingsDialog.value,
                        showFloatingDialog = showFloatingDialog.value,
                        player = player,
                        preferencesManager = preferencesManager,
                        onSettingsDismiss = { showSettingsDialog.value = false; isShowingSettingsDialog = false },
                        onFloatingDismiss = { showFloatingDialog.value = false },
                        onLinkClick = { link, idx -> switchToLink(link, idx) },
                        onChannelClick = { switchToChannel(it) },
                        onEventClick = { event, linkIdx -> switchToEventFromLiveEvent(event, linkIdx) },
                        onMessageBannerClick = {
                            val url = messageBannerUrl.value
                            if (url.isNotBlank()) {
                                try {
                                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                                } catch (_: Exception) {}
                            }
                        },
                    )
                }
            }
        }
        val rootLayout = android.widget.FrameLayout(this).apply {
            addView(
                android.view.LayoutInflater.from(this@PlayerActivity)
                    .inflate(R.layout.activity_player, null),
                android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            addView(
                (binding as androidx.compose.ui.platform.ComposeView),
                android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
        }
        setContentView(rootLayout)
        playerViewRef = rootLayout.findViewById(R.id.player_view)
        playerContainer = rootLayout.findViewById(R.id.player_container)

        windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (DeviceUtils.isTvDevice) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }

        val currentOrientation = resources.configuration.orientation
        val isLandscape = DeviceUtils.isTvDevice || currentOrientation == Configuration.ORIENTATION_LANDSCAPE

        setupWindowFlags(isLandscape)
        setupSystemUI(isLandscape)
        if (!DeviceUtils.isTvDevice) setupWindowInsets(window.decorView)

        parseIntent()

        if (contentType == ContentType.CHANNEL && contentId.isNotEmpty()) {
            val cacheKey = intent.getStringExtra(EXTRA_CHANNEL_LIST_KEY)
            val cachedList = cacheKey?.let { ChannelListCache.get(it) }
            if (!cachedList.isNullOrEmpty()) {

                viewModel.setChannelList(cachedList)
                viewModel.refreshChannelData(contentId)
            } else {

                viewModel.loadAllChannelsForList(
                    categoryId = intentCategoryId?.takeIf { it.isNotEmpty() } ?: channelData?.categoryId ?: "",
                    refreshChannelId = contentId
                )
            }
        }

        applyOrientationSettings(isLandscape)

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        gestureVolume = if (maxVol > 0) (curVol * 100f / maxVol).toInt() else 100

        setupComposeControls()
        setupRelatedChannels()
        setupLinksUI()
        setupMessageBanner()
        configurePlayerInteractions()
        setupBackHandler()

        playerViewRef.useController = false

        if (DeviceUtils.isTvDevice) {
            relatedContentState.value = RelatedContentState.Hidden
            relatedContentState.value = RelatedContentState.Hidden
        } else if (!isLandscape) {
            relatedContentState.value = RelatedContentState.Loading
        }

        window.decorView.viewTreeObserver.addOnPreDrawListener(
            object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    window.decorView.viewTreeObserver.removeOnPreDrawListener(this)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        startPostponedEnterTransition()
                    }
                    return true
                }
            }
        )

        setupPlayer()
        loadRelatedContent()

        viewModel.refreshedChannel.observe(this) { freshChannel ->
            if (freshChannel != null && freshChannel.links != null && freshChannel.links.isNotEmpty()) {
                if (allEventLinks.isEmpty() || allEventLinks.size < freshChannel.links.size) {
                    allEventLinks = freshChannel.links.map {
                        LiveEventLink(
                            quality = it.quality,
                            url = it.url,
                            cookie = it.cookie,
                            referer = it.referer,
                            origin = it.origin,
                            userAgent = it.userAgent,
                            xForwardedFor = it.xForwardedFor,
                            drmScheme = it.drmScheme,
                            drmLicenseUrl = it.drmLicenseUrl
                        )
                    }

                    val matchIndex = allEventLinks.indexOfFirst { it.url == streamUrl }
                    if (matchIndex != -1) {
                        currentLinkIndex = matchIndex
                    }

                    val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                    updateLinksForOrientation(isLandscape)
                }
            }
        }

        viewModel.channelListItems.observe(this) { items ->
            if (items.isNullOrEmpty() || contentType != ContentType.CHANNEL) return@observe
            val pendingNum = pendingChannelNumber
            if (pendingNum != -1) {
                pendingChannelNumber = -1
                pendingChannelDirection = 0
                val index = pendingNum - 1
                if (index in items.indices) {
                    val targetChannel = items[index]
                    if (targetChannel.id != contentId) switchToChannel(targetChannel)
                    showChannelOverlay((index + 1).toString(), targetChannel)
                    channelNumberHandler.removeCallbacks(overlayHideRunnable)
                    channelNumberHandler.postDelayed(overlayHideRunnable, 2000)
                } else {

                    showChannelOverlayState.value = null
                }
                return@observe
            }
            val direction = pendingChannelDirection
            if (direction != 0) {
                pendingChannelDirection = 0
                val currentIndex = items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                val targetIndex = (currentIndex + direction).coerceIn(0, items.size - 1)
                val targetChannel = items[targetIndex]
                if (targetChannel.id != contentId) {
                    switchToChannel(targetChannel)
                }

                showChannelOverlay((targetIndex + 1).toString(), targetChannel)
                channelNumberHandler.removeCallbacks(overlayHideRunnable)
                channelNumberHandler.postDelayed(overlayHideRunnable, 2000)
            }
        }

        viewModel.relatedItems.observe(this) { channels ->
            if (contentType != ContentType.CHANNEL) return@observe
            relatedChannels = channels
            relatedContentState.value = if (channels.isEmpty()) RelatedContentState.Hidden else RelatedContentState.Channels(channels)
        }

        viewModel.relatedLiveEvents.observe(this) { liveEvents ->
            if (contentType != ContentType.EVENT) return@observe
            relatedContentState.value = if (liveEvents.isEmpty()) RelatedContentState.Hidden else RelatedContentState.Events(liveEvents)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
            playerViewRef.hideController()
            return
        }

        val isLandscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE

        setupWindowFlags(isLandscape)
        setupSystemUI(isLandscape)
        applyOrientationSettings(isLandscape)
        setSubtitleTextSize()
        updateMessageBannerForOrientation(isLandscape)
        updateLinksForOrientation(isLandscape)
        applyAdapterColors()

        if (player?.playbackState == Player.STATE_BUFFERING) {
            playerViewRef.hideController()
        }

        window.decorView.post {
            playerContainer.requestLayout()
            playerViewRef.requestLayout()
        }
    }

    private fun applyAdapterColors() {  }
    private fun applyResizeModeForOrientation(isLandscape: Boolean) {
        if (isLandscape) {
            playerViewRef.resizeMode = networkLandscapeResizeMode
        } else {
            playerViewRef.resizeMode = networkPortraitResizeMode
        }
    }

    private fun applyOrientationSettings(isLandscape: Boolean) {
        adjustLayoutForOrientation(isLandscape)
        applyResizeModeForOrientation(isLandscape)
    }

    private fun adjustLayoutForOrientation(isLandscape: Boolean) {
        if (isLandscape) {
            enterFullscreen()

            val params = playerContainer.layoutParams as ConstraintLayout.LayoutParams
            params.width = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
            params.height = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
            params.topMargin = 0
            params.bottomMargin = 0
            params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
            params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
            params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
            params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID

            playerContainer.setPadding(0, 0, 0, 0)
            playerContainer.layoutParams = params

            playerViewRef.controllerAutoShow = false
            playerViewRef.controllerShowTimeoutMs = 3000

        } else {

            if (contentType == ContentType.NETWORK_STREAM) {
                val topInset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    window.decorView.rootWindowInsets?.getInsets(WindowInsets.Type.systemBars())?.top ?: 0
                } else {
                    @Suppress("DEPRECATION") window.decorView.rootWindowInsets?.systemWindowInsetTop ?: 0
                }
                val params = playerContainer.layoutParams as ConstraintLayout.LayoutParams
                params.width = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
                params.height = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
                params.topMargin = topInset
                params.bottomMargin = 0
                params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
                params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
                params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
                params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
                params.dimensionRatio = null

                playerContainer.setPadding(0, 0, 0, 0)
                playerContainer.layoutParams = params
            } else {
                exitFullscreen()
            }

            playerViewRef.controllerAutoShow = false
            playerViewRef.controllerShowTimeoutMs = 5000
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("SAVE_CONTENT_TYPE", contentType.name)
        outState.putParcelable("SAVE_CHANNEL_DATA", channelData)
        outState.putParcelable("SAVE_EVENT_DATA", eventData)
        outState.putParcelableArrayList("SAVE_ALL_LINKS", ArrayList(allEventLinks))
        outState.putInt("SAVE_LINK_INDEX", currentLinkIndex)
        outState.putString("SAVE_CONTENT_ID", contentId)
        outState.putString("SAVE_CONTENT_NAME", contentName)
        outState.putString("SAVE_STREAM_URL", streamUrl)
        outState.putString("SAVE_CATEGORY_ID", intentCategoryId)
        outState.putString("SAVE_SELECTED_GROUP", intentSelectedGroup)
        outState.putBoolean("SAVE_IS_SPORTS", intentIsSports)
        outState.putLong("SAVE_PLAYBACK_POSITION", player?.currentPosition ?: 0L)
        if (preferencesManager.isRememberAspectRatioEnabled()) {
            outState.putInt("SAVE_RESIZE_LANDSCAPE", networkLandscapeResizeMode)
            outState.putInt("SAVE_RESIZE_PORTRAIT", networkPortraitResizeMode)
        }
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val typeName = savedInstanceState.getString("SAVE_CONTENT_TYPE") ?: return
        contentType = ContentType.valueOf(typeName)
        channelData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            savedInstanceState.getParcelable("SAVE_CHANNEL_DATA", Channel::class.java)
        } else {
            @Suppress("DEPRECATION") savedInstanceState.getParcelable("SAVE_CHANNEL_DATA")
        }
        eventData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            savedInstanceState.getParcelable("SAVE_EVENT_DATA", LiveEvent::class.java)
        } else {
            @Suppress("DEPRECATION") savedInstanceState.getParcelable("SAVE_EVENT_DATA")
        }
        allEventLinks = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            savedInstanceState.getParcelableArrayList("SAVE_ALL_LINKS", LiveEventLink::class.java) ?: emptyList()
        } else {
            @Suppress("DEPRECATION") savedInstanceState.getParcelableArrayList<LiveEventLink>("SAVE_ALL_LINKS") ?: emptyList()
        }
        currentLinkIndex = savedInstanceState.getInt("SAVE_LINK_INDEX", 0)
        contentId = savedInstanceState.getString("SAVE_CONTENT_ID", "")
        contentName = savedInstanceState.getString("SAVE_CONTENT_NAME", "")
        streamUrl = savedInstanceState.getString("SAVE_STREAM_URL", "")
        intentCategoryId = savedInstanceState.getString("SAVE_CATEGORY_ID")
        intentSelectedGroup = savedInstanceState.getString("SAVE_SELECTED_GROUP")
        intentIsSports = savedInstanceState.getBoolean("SAVE_IS_SPORTS", false)
        if (preferencesManager.isRememberAspectRatioEnabled()) {
            val savedResizeLandscape = savedInstanceState.getInt("SAVE_RESIZE_LANDSCAPE", -1)
            val savedResizePortrait = savedInstanceState.getInt("SAVE_RESIZE_PORTRAIT", -1)
            if (savedResizeLandscape != -1) networkLandscapeResizeMode = savedResizeLandscape
            if (savedResizePortrait != -1) networkPortraitResizeMode = savedResizePortrait
            if (savedResizeLandscape != -1 || savedResizePortrait != -1) resizeModesRestoredFromState = true
        }
    }

    override fun onStart() {
        super.onStart()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isPipSupported) {
            setPictureInPictureParams(updatePipParams())
        }
        screenOffReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> isScreenOff = true
                    Intent.ACTION_SCREEN_ON  -> isScreenOff = false
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenOffReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        isScreenOff = false
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        applyOrientationSettings(isLandscape)

        if (player == null) {
            setupPlayer()
        }
        if (contentType == ContentType.CHANNEL && viewModel.channelListItems.value.isNullOrEmpty()) {
            viewModel.loadAllChannelsForList(intentCategoryId?.takeIf { it.isNotEmpty() } ?: channelData?.categoryId ?: "")
        }
        playerViewRef.onResume()
        playerViewRef.player = player
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        if (!isInPictureInPictureMode) {

            pipReceiver?.let {
                unregisterReceiver(it)
                pipReceiver = null
            }
            isInPipMode = false
            isEnteringPip = false
            isInPip = false
            updateLinksState()

            super.onPictureInPictureModeChanged(false, newConfig)

            controlsState.show(lifecycleScope)

            if (wasLockedBeforePip) {
                controlsState.lock()
                wasLockedBeforePip = false
            }

            exitPipUIMode(newConfig)
            return
        }

        isInPipMode = true
        isEnteringPip = false
        isInPip = true
        updateLinksState()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            setPictureInPictureParams(updatePipParams(enter = true))
        }

        controlsState.hide()

        val pipParams = playerContainer.layoutParams as ConstraintLayout.LayoutParams
        pipParams.dimensionRatio = null
        pipParams.topMargin = 0
        pipParams.bottomMargin = 0
        pipParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        pipParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        pipParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        pipParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        playerContainer.layoutParams = pipParams

        setupPipReceiver()

        super.onPictureInPictureModeChanged(true, newConfig)
    }

    private fun exitPipUIMode(newConfig: Configuration) {
        setSubtitleTextSize()

        val isLandscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE

        setupWindowFlags(isLandscape)
        setupSystemUI(isLandscape)

        applyOrientationSettings(isLandscape)

        if (!isLandscape) {
            val params = playerContainer.layoutParams as ConstraintLayout.LayoutParams
            params.dimensionRatio = "H,16:9"
            params.topMargin = 0
            params.bottomToBottom = ConstraintLayout.LayoutParams.UNSET
            playerContainer.layoutParams = params

            val hasRelated = relatedChannels.isNotEmpty() ||
                (contentType == ContentType.EVENT)
            if (hasRelated) {
                relatedContentState.value = RelatedContentState.Channels(relatedChannels)
            }
        }

        if (wasLockedBeforePip) {
            controlsState.isLocked = true
            wasLockedBeforePip = false
        } else {
            controlsState.isLocked = false
        }

        playerViewRef.useController = false
        updateLinksForOrientation(isLandscape)
    }

    @SuppressLint("NewApi")
    override fun onUserLeaveHint() {
        val isForegrounded = lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
        if (!DeviceUtils.isTvDevice && isPipSupported && player?.isPlaying == true && isForegrounded && !isFinishing) {
            isEnteringPip = true
            wasLockedBeforePip = controlsState.isLocked
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                enterPictureInPictureMode(updatePipParams(enter = true))
            } else {
                enterPictureInPictureMode()
            }
        }
        super.onUserLeaveHint()
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isInPipMode -> return
                    channelNumberInput.isNotEmpty() || pendingChannelIndex != -1 || pendingChannelDirection != 0 || pendingChannelNumber != -1 -> cancelNumberInput()
                    showChannelList.value -> showChannelList.value = false
                    else -> finish()
                }
            }
        })
    }

    private fun cancelNumberInput() {
        channelNumberInput = ""
        pendingChannelIndex = -1
        pendingChannelDirection = 0
        pendingChannelNumber = -1
        channelNumberHandler.removeCallbacks(channelNumberRunnable)
        channelNumberHandler.removeCallbacks(overlayHideRunnable)
        showChannelOverlayState.value = null
    }
    private fun clearNumberTyping() {
        channelNumberInput = ""
        channelNumberHandler.removeCallbacks(channelNumberRunnable)
        channelNumberHandler.removeCallbacks(overlayHideRunnable)

    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val code = event.keyCode
        if (code == android.view.KeyEvent.KEYCODE_MEDIA_NEXT ||
            code == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
            code == android.view.KeyEvent.KEYCODE_CHANNEL_UP ||
            code == android.view.KeyEvent.KEYCODE_CHANNEL_DOWN) {
            return when (event.action) {
                android.view.KeyEvent.ACTION_DOWN -> onKeyDown(code, event)
                android.view.KeyEvent.ACTION_UP   -> onKeyUp(code, event)
                else -> super.dispatchKeyEvent(event)
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyUp(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        return when (keyCode) {
            android.view.KeyEvent.KEYCODE_CHANNEL_UP,
            android.view.KeyEvent.KEYCODE_MEDIA_NEXT,
            android.view.KeyEvent.KEYCODE_CHANNEL_DOWN,
            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                val direction = when (keyCode) {
                    android.view.KeyEvent.KEYCODE_CHANNEL_UP,
                    android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> +1
                    else -> -1
                }
                val index = pendingChannelIndex
                pendingChannelIndex = -1
                val items = viewModel.channelListItems.value

                when {
                    contentType == ContentType.EVENT -> {
                        if (allEventLinks.size > 1) {
                            val targetIndex = (currentLinkIndex + direction).coerceIn(0, allEventLinks.size - 1)
                            if (targetIndex != currentLinkIndex) {
                                switchToLink(allEventLinks[targetIndex], targetIndex)
                            }
                        }
                    }
                    index != -1 && !items.isNullOrEmpty() && index in items.indices -> {
                        pendingChannelDirection = 0
                        val targetChannel = items[index]
                        if (targetChannel.id != contentId) switchToChannel(targetChannel)
                        channelNumberHandler.removeCallbacks(overlayHideRunnable)
                        channelNumberHandler.postDelayed(overlayHideRunnable, 2000)
                    }
                    index == -1 && !items.isNullOrEmpty() && pendingChannelDirection != 0 -> {
                        val dir = pendingChannelDirection
                        pendingChannelDirection = 0
                        val currentIndex = items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                        val targetIndex = (currentIndex + dir).coerceIn(0, items.size - 1)
                        val targetChannel = items[targetIndex]
                        if (targetChannel.id != contentId) {
                            switchToChannel(targetChannel)
                            showChannelOverlay((targetIndex + 1).toString(), targetChannel)
                        }
                        channelNumberHandler.removeCallbacks(overlayHideRunnable)
                        channelNumberHandler.postDelayed(overlayHideRunnable, 2000)
                    }
                    items.isNullOrEmpty() -> {
                        pendingChannelDirection = direction
                        viewModel.loadAllChannelsForList(
                            intentCategoryId?.takeIf { it.isNotEmpty() } ?: channelData?.categoryId ?: ""
                        )
                    }
                }
                true
            }
            else -> super.onKeyUp(keyCode, event)
        }
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        return when (keyCode) {
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                cancelNumberInput()
                player?.let {
                    val hasError = errorMessage.value.isNotBlank()
                    val hasEnded = it.playbackState == Player.STATE_ENDED
                    if (hasError || hasEnded) retryPlayback()
                    else if (it.isPlaying) it.pause() else it.play()
                }
                controlsState.show(lifecycleScope)
                true
            }
            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (showChannelList.value) return super.onKeyDown(keyCode, event)
                cancelNumberInput()
                player?.let {
                    val newPosition = it.currentPosition + skipMs
                    if (it.isCurrentWindowLive && it.duration != C.TIME_UNSET && newPosition >= it.duration) {
                        it.seekTo(it.duration)
                    } else if (it.duration == C.TIME_UNSET) {
                        it.seekTo(newPosition)
                    } else {
                        it.seekTo(newPosition.coerceAtMost(it.duration))
                    }
                }
                controlsState.show(lifecycleScope)
                true
            }
            android.view.KeyEvent.KEYCODE_MEDIA_REWIND,
            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (showChannelList.value) return super.onKeyDown(keyCode, event)
                cancelNumberInput()
                player?.let { it.seekTo((it.currentPosition - skipMs).coerceAtLeast(0L)) }
                controlsState.show(lifecycleScope)
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                cancelNumberInput()
                controlsState.show(lifecycleScope)
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                val channelListItems = viewModel.channelListItems.value
                val isChannelListAvailable = contentType == ContentType.CHANNEL &&
                    !channelListItems.isNullOrEmpty() &&
                    (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE || DeviceUtils.isTvDevice)
                if (isChannelListAvailable) {
                    if (!showChannelList.value) cancelNumberInput()
                    showChannelList.value = !showChannelList.value
                } else {
                    controlsState.show(lifecycleScope)
                }
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (showChannelList.value) {
                    cancelNumberInput()
                    showChannelList.value = false
                    controlsState.show(lifecycleScope)
                } else {
                    cancelNumberInput()
                    player?.let {
                        val hasError = errorMessage.value.isNotBlank()
                        val hasEnded = it.playbackState == Player.STATE_ENDED
                        if (hasError || hasEnded) retryPlayback()
                        else if (it.isPlaying) it.pause() else it.play()
                    }
                    controlsState.show(lifecycleScope)
                }
                true
            }
            android.view.KeyEvent.KEYCODE_CHANNEL_UP,
            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (showChannelList.value) {
                    cancelNumberInput()
                    showChannelList.value = false
                    return true
                }
                clearNumberTyping()
                if (contentType == ContentType.EVENT) {
                    if (allEventLinks.size > 1) {
                        val nextIndex = (currentLinkIndex + 1).coerceAtMost(allEventLinks.size - 1)
                        if (nextIndex != currentLinkIndex) switchToLink(allEventLinks[nextIndex], nextIndex)
                    }
                    controlsState.show(lifecycleScope)
                    return true
                }
                val items = viewModel.channelListItems.value
                if (contentType == ContentType.CHANNEL) {
                    if (!items.isNullOrEmpty()) {
                        val currentIndex = if (pendingChannelIndex != -1) pendingChannelIndex
                            else items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                        val nextIndex = (currentIndex + 1).coerceAtMost(items.size - 1)
                        pendingChannelIndex = nextIndex
                        channelNumberHandler.removeCallbacks(overlayHideRunnable)
                        showChannelOverlay((nextIndex + 1).toString(), items[nextIndex])
                    } else {
                        pendingChannelDirection = +1
                        showChannelOverlay("...", null)
                        channelNumberHandler.postDelayed(overlayHideRunnable, 4000)
                    }
                    controlsState.show(lifecycleScope)
                }
                true
            }
            android.view.KeyEvent.KEYCODE_CHANNEL_DOWN,
            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (showChannelList.value) {
                    cancelNumberInput()
                    showChannelList.value = false
                    return true
                }
                clearNumberTyping()
                if (contentType == ContentType.EVENT) {
                    if (allEventLinks.size > 1) {
                        val prevIndex = (currentLinkIndex - 1).coerceAtLeast(0)
                        if (prevIndex != currentLinkIndex) switchToLink(allEventLinks[prevIndex], prevIndex)
                    }
                    controlsState.show(lifecycleScope)
                    return true
                }
                val items = viewModel.channelListItems.value
                if (contentType == ContentType.CHANNEL) {
                    if (!items.isNullOrEmpty()) {
                        val currentIndex = if (pendingChannelIndex != -1) pendingChannelIndex
                            else items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                        val prevIndex = (currentIndex - 1).coerceAtLeast(0)
                        pendingChannelIndex = prevIndex
                        channelNumberHandler.removeCallbacks(overlayHideRunnable)
                        showChannelOverlay((prevIndex + 1).toString(), items[prevIndex])
                    } else {
                        pendingChannelDirection = -1
                        showChannelOverlay("...", null)
                        channelNumberHandler.postDelayed(overlayHideRunnable, 4000)
                    }
                    controlsState.show(lifecycleScope)
                }
                true
            }
            android.view.KeyEvent.KEYCODE_0,
            android.view.KeyEvent.KEYCODE_1,
            android.view.KeyEvent.KEYCODE_2,
            android.view.KeyEvent.KEYCODE_3,
            android.view.KeyEvent.KEYCODE_4,
            android.view.KeyEvent.KEYCODE_5,
            android.view.KeyEvent.KEYCODE_6,
            android.view.KeyEvent.KEYCODE_7,
            android.view.KeyEvent.KEYCODE_8,
            android.view.KeyEvent.KEYCODE_9 -> {
                if (!DeviceUtils.isTvDevice) return super.onKeyDown(keyCode, event)
                if (event?.repeatCount != 0) return true
                if (showChannelList.value) return true
                pendingChannelDirection = 0
                channelNumberInput += (keyCode - android.view.KeyEvent.KEYCODE_0).toString()
                channelNumberHandler.removeCallbacks(overlayHideRunnable)
                showChannelOverlay(channelNumberInput, null)
                channelNumberHandler.removeCallbacks(channelNumberRunnable)
                channelNumberHandler.postDelayed(channelNumberRunnable, 2000)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun showChannelOverlay(number: String, channel: com.livetvpro.app.data.models.Channel?) {
        showChannelOverlayState.value = null
        return

    }
    private fun navigateToChannelByNumber() {
        val number = channelNumberInput.toIntOrNull()
        channelNumberInput = ""
        if (number == null || number <= 0) {
            showChannelOverlayState.value = null
            return
        }
        if (contentType != ContentType.CHANNEL) {
            showChannelOverlayState.value = null
            return
        }
        val items = viewModel.channelListItems.value
        if (items.isNullOrEmpty()) {

            pendingChannelNumber = number
            showChannelOverlay("...", null)
            viewModel.loadAllChannelsForList(
                intentCategoryId?.takeIf { it.isNotEmpty() } ?: channelData?.categoryId ?: ""
            )
            channelNumberHandler.postDelayed(overlayHideRunnable, 3000)
            return
        }
        val index = number - 1
        showChannelOverlayState.value = null
        if (index in items.indices) {
            switchToChannel(items[index])
            showChannelOverlay((index + 1).toString(), items[index])
            channelNumberHandler.removeCallbacks(overlayHideRunnable)
            channelNumberHandler.postDelayed(overlayHideRunnable, 2000)
        }
    }

    private fun setupComposeControls() {
    }

    internal fun cycleAspectRatio() {
        val isLandscape = DeviceUtils.isTvDevice || resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val current = playerViewRef.resizeMode
        val next = when (current) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT   -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM  -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            AspectRatioFrameLayout.RESIZE_MODE_FILL  -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
            else                                     -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }

        if (preferencesManager.isRememberAspectRatioEnabled()) {
            if (isLandscape) networkLandscapeResizeMode = next
            else networkPortraitResizeMode = next
            if (isLandscape) preferencesManager.setSavedAspectRatio(next)
            else preferencesManager.setSavedAspectRatioPortrait(next)
        }

        playerViewRef.resizeMode = next
    }

    internal fun showSettingsDialog() {
        if (player == null) return
        if (isFinishing || isDestroyed) return
        if (isShowingSettingsDialog) return
        isShowingSettingsDialog = true
        showSettingsDialog.value = true
    }

    private fun parseIntent() {
        val isExternalView = intent.action == android.content.Intent.ACTION_VIEW && intent.data != null
        if (isExternalView) {
            val uri = intent.data!!
            contentType = ContentType.NETWORK_STREAM
            contentName = uri.lastPathSegment ?: "Stream"
            contentId = "external_${System.currentTimeMillis()}"
            val rawUriString = uri.toString()
            val decodedUriString = android.net.Uri.decode(rawUriString)
            streamUrl = decodedUriString

            val parsed = PlayerStreamHelper.parseStreamUrl(decodedUriString)

            allEventLinks = listOf(
                com.livetvpro.app.data.models.LiveEventLink(
                    quality = "Auto",
                    url = parsed.url,
                    cookie = parsed.headers["Cookie"] ?: "",
                    referer = parsed.headers["Referer"] ?: "",
                    origin = parsed.headers["Origin"] ?: "",
                    userAgent = parsed.headers["User-Agent"] ?: "Default",
                    xForwardedFor = parsed.headers["X-Forwarded-For"],
                    drmScheme = parsed.drmScheme ?: "",
                    drmLicenseUrl = parsed.drmLicenseUrl
                        ?: parsed.drmKeyId?.let { id -> parsed.drmKey?.let { k -> "$id:$k" } }
                        ?: ""
                )
            )
            currentLinkIndex = 0
            return
        }

        val isNetworkStream = intent.getBooleanExtra("IS_NETWORK_STREAM", false)

        if (isNetworkStream) {
            contentType = ContentType.NETWORK_STREAM
            contentName = intent.getStringExtra("CHANNEL_NAME") ?: "Network Stream"
            contentId = "network_stream_${System.currentTimeMillis()}"

            val streamUrlRaw = intent.getStringExtra("STREAM_URL") ?: ""

            if (streamUrlRaw.contains("|")) {
                streamUrl = streamUrlRaw

                val parsed = PlayerStreamHelper.parseStreamUrl(streamUrlRaw)
                val extraDrmScheme = intent.getStringExtra("DRM_SCHEME")?.takeIf { it.isNotBlank() }
                val extraDrmLicense = intent.getStringExtra("DRM_LICENSE")?.takeIf { it.isNotBlank() }
                val resolvedDrmScheme = parsed.drmScheme ?: extraDrmScheme
                val resolvedDrmLicenseUrl: String?
                val resolvedDrmKeyId: String?
                val resolvedDrmKey: String?
                if (parsed.drmKeyId != null) {
                    resolvedDrmLicenseUrl = null
                    resolvedDrmKeyId = parsed.drmKeyId
                    resolvedDrmKey = parsed.drmKey
                } else if (extraDrmLicense != null) {
                    val colonIdx = extraDrmLicense.indexOf(':')
                    if (extraDrmLicense.startsWith("http", ignoreCase = true)) {
                        resolvedDrmLicenseUrl = extraDrmLicense
                        resolvedDrmKeyId = null
                        resolvedDrmKey = null
                    } else if (colonIdx != -1) {
                        resolvedDrmLicenseUrl = null
                        resolvedDrmKeyId = extraDrmLicense.substring(0, colonIdx).trim()
                        resolvedDrmKey = extraDrmLicense.substring(colonIdx + 1).trim()
                    } else {
                        resolvedDrmLicenseUrl = extraDrmLicense
                        resolvedDrmKeyId = null
                        resolvedDrmKey = null
                    }
                } else {
                    resolvedDrmLicenseUrl = parsed.drmLicenseUrl
                    resolvedDrmKeyId = null
                    resolvedDrmKey = null
                }
                val mergedLink = LiveEventLink(
                    quality = "Network Stream",
                    url = parsed.url,
                    cookie = parsed.headers["Cookie"] ?: "",
                    referer = parsed.headers["Referer"] ?: "",
                    origin = parsed.headers["Origin"] ?: "",
                    userAgent = parsed.headers["User-Agent"] ?: intent.getStringExtra("USER_AGENT") ?: "Default",
                    xForwardedFor = parsed.headers["X-Forwarded-For"],
                    drmScheme = resolvedDrmScheme,
                    drmLicenseUrl = resolvedDrmLicenseUrl
                        ?: resolvedDrmKeyId?.let { id -> resolvedDrmKey?.let { k -> "$id:$k" } }
                )
                streamUrl = PlayerStreamHelper.buildStreamUrl(mergedLink)

                allEventLinks = listOf(mergedLink)
            } else {
                val cookie = intent.getStringExtra("COOKIE") ?: ""
                val referer = intent.getStringExtra("REFERER") ?: ""
                val origin = intent.getStringExtra("ORIGIN") ?: ""
                val drmLicense = intent.getStringExtra("DRM_LICENSE") ?: ""
                val userAgent = intent.getStringExtra("USER_AGENT") ?: "Default"
                val drmScheme = intent.getStringExtra("DRM_SCHEME") ?: "clearkey"

                allEventLinks = listOf(
                    LiveEventLink(
                        quality = "Network Stream",
                        url = streamUrlRaw,
                        cookie = cookie,
                        referer = referer,
                        origin = origin,
                        userAgent = userAgent,
                        drmScheme = drmScheme,
                        drmLicenseUrl = drmLicense
                    )
                )

                streamUrl = PlayerStreamHelper.buildStreamUrl(allEventLinks[0])
            }

            currentLinkIndex = 0
            return
        }

        channelData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CHANNEL, Channel::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_CHANNEL)
        }

        eventData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_EVENT, LiveEvent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_EVENT)
        }

        val passedLinkIndex = intent.getIntExtra(EXTRA_SELECTED_LINK_INDEX, -1)

        intentCategoryId = intent.getStringExtra(EXTRA_CATEGORY_ID)
        intentSelectedGroup = intent.getStringExtra(EXTRA_SELECTED_GROUP)
        intentIsSports = intent.getBooleanExtra(EXTRA_IS_SPORTS, false)

        val passedRelatedChannels: List<Channel>? =
            intent.getStringExtra(EXTRA_RELATED_CHANNELS_KEY)?.let { ChannelListCache.get(it) }

        if (channelData != null) {
            contentType = ContentType.CHANNEL
            val channel = channelData!!
            contentId = channel.id
            contentName = channel.name

            if (channel.links != null && channel.links.isNotEmpty()) {
                allEventLinks = channel.links.map {
                    LiveEventLink(
                        quality = it.quality,
                        url = it.url,
                        cookie = it.cookie,
                        referer = it.referer,
                        origin = it.origin,
                        userAgent = it.userAgent,
                        xForwardedFor = it.xForwardedFor,
                        drmScheme = it.drmScheme,
                        drmLicenseUrl = it.drmLicenseUrl
                    )
                }

                if (passedLinkIndex in allEventLinks.indices) {
                    currentLinkIndex = passedLinkIndex
                } else {
                    val matchIndex = allEventLinks.indexOfFirst { it.url == channel.streamUrl }
                    currentLinkIndex = if (matchIndex != -1) matchIndex else 0
                }

                streamUrl = PlayerStreamHelper.buildStreamUrl(allEventLinks[currentLinkIndex])
            } else {
                streamUrl = channel.streamUrl
                allEventLinks = emptyList()
            }

            if (allEventLinks.isEmpty()) {
            }

        } else if (eventData != null) {
            contentType = ContentType.EVENT
            val event = eventData!!
            contentId = event.id
            contentName = event.title.ifEmpty { "${event.team1Name} vs ${event.team2Name}" }

            allEventLinks = event.links

            if (allEventLinks.isNotEmpty()) {
                currentLinkIndex = if (passedLinkIndex in allEventLinks.indices) passedLinkIndex else 0
                streamUrl = PlayerStreamHelper.buildStreamUrl(allEventLinks[currentLinkIndex])
            } else {
                currentLinkIndex = 0
                streamUrl = ""
            }

        } else {
            finish()
            return
        }
    }

    private fun setupRelatedChannels() {
        if (contentType == ContentType.NETWORK_STREAM || DeviceUtils.isTvDevice) {
            relatedContentState.value = RelatedContentState.Hidden
            return
        }
        relatedContentState.value = RelatedContentState.Loading
    }

    private fun setupLinksUI() {
        updateLinksState()
    }

    private fun updateLinksState() {
        linksState.value = if (isInPipMode || allEventLinks.size <= 1) emptyList() else allEventLinks
        selectedLinkState.value = currentLinkIndex
    }

    private fun updateLinksForOrientation(isLandscape: Boolean) {
        updateLinksState()
    }

    private fun loadRelatedContent() {
        if (DeviceUtils.isTvDevice) return
        when (contentType) {
            ContentType.CHANNEL -> {
                channelData?.let { channel ->
                    val passedRelatedChannels: List<Channel>? =
                        intent.getStringExtra(EXTRA_RELATED_CHANNELS_KEY)?.let { ChannelListCache.get(it) }

                    if (passedRelatedChannels != null && passedRelatedChannels.isNotEmpty()) {
                        val filteredChannels = passedRelatedChannels.filter { it.id != channel.id }
                        viewModel.setRelatedChannels(filteredChannels)
                    } else if (intentIsSports) {
                        viewModel.loadRandomRelatedSports(channel.id)
                    } else {
                        val categoryId = intentCategoryId?.takeIf { it.isNotEmpty() } ?: channel.categoryId
                        viewModel.loadRandomRelatedChannels(categoryId, channel.id, intentSelectedGroup)
                    }
                }
            }
            ContentType.EVENT -> {
                eventData?.let { event ->
                    viewModel.loadRelatedEvents(event.id)
                }
            }
            ContentType.NETWORK_STREAM -> {
            }
        }
    }

    internal fun switchToChannel(newChannel: Channel, linkIndex: Int = -1) {
        releasePlayer()
        val previousContentType = contentType
        channelData = newChannel
        eventData = null
        contentType = ContentType.CHANNEL
        contentId = newChannel.id
        contentName = newChannel.name

        if (newChannel.links != null && newChannel.links.isNotEmpty()) {
            allEventLinks = newChannel.links.map {
                LiveEventLink(
                    quality = it.quality,
                    url = it.url,
                    cookie = it.cookie,
                    referer = it.referer,
                    origin = it.origin,
                    userAgent = it.userAgent,
                    xForwardedFor = it.xForwardedFor,
                    drmScheme = it.drmScheme,
                    drmLicenseUrl = it.drmLicenseUrl
                )
            }
            currentLinkIndex = if (linkIndex in allEventLinks.indices) linkIndex else 0
            streamUrl = allEventLinks.getOrNull(currentLinkIndex)?.let { PlayerStreamHelper.buildStreamUrl(it) } ?: newChannel.streamUrl
        } else {
            allEventLinks = emptyList()
            streamUrl = newChannel.streamUrl
        }

        setupPlayer()
        setupLinksUI()

        relatedContentState.value = RelatedContentState.Loading

        val isSports = newChannel.categoryId == "sports" || intentIsSports && previousContentType != ContentType.EVENT
        val categoryId = newChannel.categoryId.takeIf { it.isNotEmpty() } ?: intentCategoryId ?: ""
        val group = if (previousContentType == ContentType.EVENT) null else intentSelectedGroup

        if (isSports) {
            viewModel.loadRandomRelatedSports(newChannel.id)
        } else {
            viewModel.loadRandomRelatedChannels(categoryId, newChannel.id, group)
        }
    }

    private fun switchToEvent(relatedChannel: Channel) {
        switchToChannel(relatedChannel)
    }

    private fun switchToEventFromLiveEvent(newEvent: LiveEvent, linkIndex: Int = 0) {
        try {
            releasePlayer()

            eventData = newEvent
            channelData = null
            contentType = ContentType.EVENT
            contentId = newEvent.id
            contentName = newEvent.title.ifEmpty { "${newEvent.team1Name} vs ${newEvent.team2Name}" }

            allEventLinks = newEvent.links

            if (allEventLinks.isNotEmpty()) {
                currentLinkIndex = if (linkIndex in allEventLinks.indices) linkIndex else 0
                streamUrl = PlayerStreamHelper.buildStreamUrl(allEventLinks[currentLinkIndex])
            } else {
                currentLinkIndex = 0
                streamUrl = ""
            }

            setupPlayer()
            setupLinksUI()

            relatedContentState.value = RelatedContentState.Loading

            viewModel.loadRelatedEvents(newEvent.id)

        } catch (e: Exception) {
        }
    }

    internal fun switchToLink(link: LiveEventLink, position: Int) {
        currentLinkIndex = position
        selectedLinkState.value = position
        streamUrl = PlayerStreamHelper.buildStreamUrl(link)
        releasePlayer()
        setupPlayer()
    }

    override fun onPause() {
        super.onPause()
        cancelNumberInput()

        val isPip = isEnteringPip ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode)
        if (!isPip) {
            playerViewRef.onPause()
            player?.pause()
        }
    }

    override fun onStop() {
        super.onStop()
        screenOffReceiver?.let {
            try { unregisterReceiver(it) } catch (_: Exception) {}
            screenOffReceiver = null
        }
        if (isInPipMode) {
            if (isScreenOff) return
            if (isFinishing) {
                finish()
            } else {
                releasePlayer()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        channelNumberHandler.removeCallbacks(channelNumberRunnable)
        channelNumberHandler.removeCallbacks(overlayHideRunnable)
        mainHandler.removeCallbacksAndMessages(null)
        unregisterPipReceiver()
        releasePlayer()
    }

    private fun releasePlayer() {
        player?.let {
            try {
                playerListener?.let { listener -> it.removeListener(listener) }
                it.stop()
                it.release()
            } catch (t: Throwable) {
            }
        }
        player = null
        playerListener = null
    }

    private fun setupPlayer() {
        if (streamUrl.isBlank()) {
            errorMessage.value = "No stream URL"
            return
        }

        val parsed = PlayerStreamHelper.parseStreamUrl(streamUrl)
        val headers = parsed.headers.toMutableMap()
        if (headers["User-Agent"].isNullOrBlank() || headers["User-Agent"] == "Default") {
            headers["User-Agent"] = "okhttp/4.12.0"
        }

        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(headers["User-Agent"] ?: "LiveTVPro/1.0")
            .setDefaultRequestProperties(headers)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)

        val clearKeyMgr: androidx.media3.exoplayer.drm.DefaultDrmSessionManager? = when {
            parsed.drmScheme != "clearkey" -> null
            parsed.drmKeyId != null && parsed.drmKey != null ->
                PlayerStreamHelper.buildClearKeyInlineManager(parsed.drmKeyId, parsed.drmKey)
            parsed.drmLicenseUrl?.trimStart()?.startsWith("{") == true ->
                PlayerStreamHelper.buildClearKeyJwkManager(parsed.drmLicenseUrl)
            parsed.drmLicenseUrl?.startsWith("http", ignoreCase = true) == true ->
                PlayerStreamHelper.buildClearKeyServerManager(parsed.drmLicenseUrl, headers)
            else -> null
        }

        val mediaSourceFactory = if (clearKeyMgr != null) {
            DefaultMediaSourceFactory(this)
                .setDataSourceFactory(dataSourceFactory)
                .setDrmSessionManagerProvider { clearKeyMgr }
        } else {
            DefaultMediaSourceFactory(this).setDataSourceFactory(dataSourceFactory)
        }

        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)

        val ts = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedChannelCountAdaptiveness(true)
                .build()
        }
        trackSelector = ts

        val exo = ExoPlayer.Builder(this)
            .setRenderersFactory(renderersFactory)
            .setTrackSelector(ts)
            .setMediaSourceFactory(mediaSourceFactory)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()

        player = exo
        playerViewRef.player = exo

        val urlLower = parsed.url.lowercase()
        val mediaItemBuilder = MediaItem.Builder().setUri(parsed.url)
        when {
            urlLower.contains("m3u8") || urlLower.contains("extension=m3u8") ->
                mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8)
            urlLower.contains(".mpd") || urlLower.contains("/dash/") || urlLower.contains("type=mpd") ->
                mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_MPD)
            urlLower.contains(".ism") || urlLower.contains(".isml") ->
                mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_SS)
            urlLower.contains(".mp4") || urlLower.contains(".m4v") ->
                mediaItemBuilder.setMimeType("video/mp4")
            urlLower.contains(".ts") || urlLower.contains("/ts") ->
                mediaItemBuilder.setMimeType("video/mp2t")
            urlLower.contains(".mkv") ->
                mediaItemBuilder.setMimeType("video/x-matroska")
        }
        if ((parsed.drmScheme == "widevine" || parsed.drmScheme == "playready") && parsed.drmLicenseUrl != null) {
            val uuid = if (parsed.drmScheme == "widevine") C.WIDEVINE_UUID else C.PLAYREADY_UUID
            val licHeaders = headers.filter { (k, _) -> k.lowercase() !in setOf("referer", "origin") }
            mediaItemBuilder.setDrmConfiguration(
                MediaItem.DrmConfiguration.Builder(uuid)
                    .setLicenseUri(parsed.drmLicenseUrl)
                    .setLicenseRequestHeaders(licHeaders)
                    .setForceDefaultLicenseUri(true)
                    .setMultiSession(false)
                    .build()
            )
        }

        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> {
                        errorMessage.value = ""
                    }
                    Player.STATE_READY -> {
                        errorMessage.value = ""
                        if (!resizeModesRestoredFromState) {
                            val savedLandscape = preferencesManager.getSavedAspectRatio()
                            val savedPortrait = preferencesManager.getSavedAspectRatioPortrait()
                            if (savedLandscape != -1) networkLandscapeResizeMode = savedLandscape
                            if (savedPortrait != -1) networkPortraitResizeMode = savedPortrait
                            resizeModesRestoredFromState = true
                            val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                            playerViewRef.resizeMode = if (isLandscape) networkLandscapeResizeMode else networkPortraitResizeMode
                        }
                        setSubtitleTextSize()
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                errorMessage.value = error.localizedMessage ?: "Playback error"
            }
        }
        playerListener = listener
        exo.addListener(listener)

        exo.setMediaItem(mediaItemBuilder.build())
        exo.prepare()
        exo.playWhenReady = true
    }

    internal fun toggleMute() {
        isMuted = PlayerStreamHelper.toggleMute(player, isMuted)
    }

    private fun setupMessageBanner() {
        val message = listenerManager.getMessage()
        if (message.isNotBlank()) {
            messageBannerText.value = message
            messageBannerUrl.value = listenerManager.getMessageUrl()
        }
    }

    private fun updateMessageBannerForOrientation(isLandscape: Boolean) {
    }

    private fun configurePlayerInteractions() {

    }

    private fun setupLockOverlay() {

    }

    internal fun toggleFullscreen() {
        if (DeviceUtils.isTvDevice) return
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    private fun exitFullscreen() {
        windowInsetsController.apply {
            show(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
        }

        val params = playerContainer.layoutParams as ConstraintLayout.LayoutParams
        params.width = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
        params.height = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
        params.dimensionRatio = "H,16:9"
        params.matchConstraintPercentHeight = -1f
        params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        params.bottomToBottom = ConstraintLayout.LayoutParams.UNSET
        playerContainer.layoutParams = params
        playerContainer.visibility = View.VISIBLE

        if (allEventLinks.size > 1) {
        }
        val hasRelated = relatedChannels.isNotEmpty() ||
            (contentType == ContentType.EVENT)
        if (hasRelated) {
            relatedContentState.value = when {
                contentType == ContentType.EVENT -> {
                    val events = viewModel.relatedLiveEvents.value
                    if (!events.isNullOrEmpty()) RelatedContentState.Events(events) else RelatedContentState.Loading
                }
                relatedChannels.isNotEmpty() -> RelatedContentState.Channels(relatedChannels)
                else -> RelatedContentState.Loading
            }
        }
    }

    private fun enterFullscreen() {
        windowInsetsController.apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        playerContainer.setPadding(0, 0, 0, 0)

        val params = playerContainer.layoutParams as ConstraintLayout.LayoutParams
        params.width = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
        params.height = ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
        params.topMargin = 0
        params.dimensionRatio = null
        params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        playerContainer.layoutParams = params

        relatedContentState.value = RelatedContentState.Hidden
    }

    private fun setSubtitleTextSize() {
        val subtitleView = playerViewRef.subtitleView ?: return
        subtitleView.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION)
    }

    private fun setSubtitleTextSizePiP() {
        val subtitleView = playerViewRef.subtitleView ?: return
        subtitleView.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * 2)
    }

    private fun prepareUIForPip() {
        controlsState.hide()
    }

    @SuppressLint("NewApi")
    internal fun enterPipMode() {
        if (!isPipSupported) return
        playerViewRef.useController = false
        setSubtitleTextSizePiP()
        isEnteringPip = true
        wasLockedBeforePip = controlsState.isLocked
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPictureInPictureMode(updatePipParams(enter = true))
        } else {
            @Suppress("DEPRECATION")
            enterPictureInPictureMode()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createPipRatio(): Rational {
        return try {
            val videoFormat = player?.videoFormat
            if (videoFormat != null && videoFormat.width > 0 && videoFormat.height > 0) {
                Rational(videoFormat.width, videoFormat.height)
            } else {
                Rational(16, 9)
            }
        } catch (e: Exception) {
            Rational(16, 9)
        }
    }

    private fun setupPipReceiver() {
        pipReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action != ACTION_MEDIA_CONTROL) return
                val currentPlayer = player ?: return
                val hasError = errorMessage.value.isNotBlank()
                val hasEnded = currentPlayer.playbackState == Player.STATE_ENDED
                when (intent.getIntExtra(EXTRA_CONTROL_TYPE, 0)) {
                    CONTROL_TYPE_PLAY -> {
                        if (hasError || hasEnded) {
                            retryPlayback()
                        } else {
                            currentPlayer.play()
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            updatePipParams()
                        }
                    }
                    CONTROL_TYPE_PAUSE -> {
                        if (hasError || hasEnded) {
                            retryPlayback()
                        } else {
                            currentPlayer.pause()
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            updatePipParams()
                        }
                    }
                    CONTROL_TYPE_REWIND -> {
                        if (!hasError && !hasEnded) {
                            val newPosition = currentPlayer.currentPosition - skipMs
                            currentPlayer.seekTo(if (newPosition < 0) 0 else newPosition)
                        }
                    }
                    CONTROL_TYPE_FORWARD -> {
                        if (!hasError && !hasEnded) {
                            val newPosition = currentPlayer.currentPosition + skipMs
                            if (currentPlayer.isCurrentWindowLive && currentPlayer.duration != C.TIME_UNSET && newPosition >= currentPlayer.duration) {
                                currentPlayer.seekTo(currentPlayer.duration)
                            } else {
                                currentPlayer.seekTo(newPosition)
                            }
                        }
                    }
                    CONTROL_TYPE_PREV_CHANNEL -> {
                        if (contentType == ContentType.CHANNEL) {
                            val items = viewModel.channelListItems.value
                            if (!items.isNullOrEmpty()) {
                                val currentIndex = items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                                val prevIndex = (currentIndex - 1).coerceAtLeast(0)
                                if (prevIndex != currentIndex) switchToChannel(items[prevIndex])
                            }
                        }
                    }
                    CONTROL_TYPE_NEXT_CHANNEL -> {
                        if (contentType == ContentType.CHANNEL) {
                            val items = viewModel.channelListItems.value
                            if (!items.isNullOrEmpty()) {
                                val currentIndex = items.indexOfFirst { it.id == contentId }.takeIf { it != -1 } ?: 0
                                val nextIndex = (currentIndex + 1).coerceAtMost(items.size - 1)
                                if (nextIndex != currentIndex) switchToChannel(items[nextIndex])
                            }
                        }
                    }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(pipReceiver, IntentFilter(ACTION_MEDIA_CONTROL), Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(pipReceiver, IntentFilter(ACTION_MEDIA_CONTROL))
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun updatePipParams(enter: Boolean = false): PictureInPictureParams {
        val builder = PictureInPictureParams.Builder()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            builder.setTitle(contentName)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val isPlaying = player?.isPlaying == true
            builder.setAutoEnterEnabled(isPlaying)
            builder.setSeamlessResizeEnabled(isPlaying)
        }

        val isPaused = player?.isPlaying != true
        builder.setActions(createPipActions(this, isPaused))
        builder.setSourceRectHint(pipRect)

        player?.videoFormat?.let { format ->
            val height = format.height
            val width = format.width
            if (height > 0 && width > 0) {
                val rational = Rational(width, height).toFloat()
                if (rational in 0.42..2.38) {
                    builder.setAspectRatio(Rational(width, height))
                }
            }
        }

        return builder.build()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createPipActions(context: Context, isPaused: Boolean): List<RemoteAction> {
        val actions = mutableListOf<RemoteAction>()
        val centerMode = preferencesManager.getCenterControlsMode()

        fun makePendingIntent(requestCode: Int, controlType: Int) =
            PendingIntent.getBroadcast(
                context, requestCode,
                Intent(ACTION_MEDIA_CONTROL).setPackage(context.packageName)
                    .putExtra(EXTRA_CONTROL_TYPE, controlType),
                PendingIntent.FLAG_IMMUTABLE
            )

        val playPauseAction = if (isPaused) {
            RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_play),
                context.getString(R.string.play), context.getString(R.string.play),
                makePendingIntent(CONTROL_TYPE_PLAY, CONTROL_TYPE_PLAY)
            )
        } else {
            RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_pause),
                context.getString(R.string.pause), context.getString(R.string.pause),
                makePendingIntent(CONTROL_TYPE_PAUSE, CONTROL_TYPE_PAUSE)
            )
        }

        val showNav = centerMode == com.livetvpro.app.data.local.PreferencesManager.CENTER_MODE_NAV_ONLY
                && contentType == ContentType.CHANNEL

        if (showNav) {
            actions.add(RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_skip_prev_channel),
                "Previous", "Previous channel",
                makePendingIntent(CONTROL_TYPE_PREV_CHANNEL, CONTROL_TYPE_PREV_CHANNEL)
            ))
            actions.add(playPauseAction)
            actions.add(RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_skip_next_channel),
                "Next", "Next channel",
                makePendingIntent(CONTROL_TYPE_NEXT_CHANNEL, CONTROL_TYPE_NEXT_CHANNEL)
            ))
        } else {
            actions.add(RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_skip_backward),
                "Rewind", "Rewind 10s",
                makePendingIntent(CONTROL_TYPE_REWIND, CONTROL_TYPE_REWIND)
            ))
            actions.add(playPauseAction)
            actions.add(RemoteAction(
                Icon.createWithResource(context, R.drawable.ic_skip_forward),
                "Forward", "Forward 10s",
                makePendingIntent(CONTROL_TYPE_FORWARD, CONTROL_TYPE_FORWARD)
            ))
        }

        return actions
    }

    internal fun retryPlayback() {
        errorMessage.value = ""

        playerViewRef.hideController()

        player?.release()
        player = null
        setupPlayer()
    }

    override fun finish() {
        try {
            releasePlayer()
            pipReceiver?.let {
                unregisterReceiver(it)
                pipReceiver = null
            }
            isInPipMode = false
            wasLockedBeforePip = false
            isInPip = false
            super.finish()
        } catch (e: Exception) {
            super.finish()
        }
    }

    @SuppressLint("NewApi")
    private fun showUnlockButton() {

    }

    private fun hideUnlockButton() {

    }

    private fun unregisterPipReceiver() {
        try {
            pipReceiver?.let {
                unregisterReceiver(it)
                pipReceiver = null
            }
        } catch (e: Exception) {

        }
    }
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.compose.runtime.Composable
private fun PlayerActivity.PlayerActivityRoot(
    activity: PlayerActivity,
    controlsState: com.livetvpro.app.ui.player.compose.PlayerControlsState,
    showChannelList: androidx.compose.runtime.MutableState<Boolean>,
    isMuted: Boolean,
    relatedContentState: com.livetvpro.app.ui.player.compose.RelatedContentState,
    links: List<com.livetvpro.app.data.models.LiveEventLink>,
    selectedLinkIndex: Int,
    messageBanner: String,
    messageBannerUrl: String,
    errorMessage: String,
    showSettingsDialog: Boolean,
    showFloatingDialog: Boolean,
    player: androidx.media3.exoplayer.ExoPlayer?,
    preferencesManager: com.livetvpro.app.data.local.PreferencesManager,
    onSettingsDismiss: () -> Unit,
    onFloatingDismiss: () -> Unit,
    onLinkClick: (com.livetvpro.app.data.models.LiveEventLink, Int) -> Unit,
    onChannelClick: (com.livetvpro.app.data.models.Channel) -> Unit,
    onEventClick: (com.livetvpro.app.data.models.LiveEvent, Int) -> Unit,
    onMessageBannerClick: () -> Unit,
) {
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isLandscape = configuration.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE ||
        com.livetvpro.app.utils.DeviceUtils.isTvDevice
    val spanCount = activity.resources.getInteger(com.livetvpro.app.R.integer.grid_column_count)
    val eventSpanCount = activity.resources.getInteger(com.livetvpro.app.R.integer.event_span_count)

    val statusBarHeight = androidx.compose.foundation.layout.WindowInsets.statusBars
        .asPaddingValues().calculateTopPadding()
    val navBarHeight = androidx.compose.foundation.layout.WindowInsets.navigationBars
        .asPaddingValues().calculateBottomPadding()

    val isPlaying by androidx.compose.runtime.produceState(initialValue = false, player) {
        while (true) {
            value = player?.isPlaying == true
            kotlinx.coroutines.delay(100)
        }
    }
    var currentPosition by androidx.compose.runtime.remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    var duration by androidx.compose.runtime.remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    var bufferedPosition by androidx.compose.runtime.remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    androidx.compose.runtime.LaunchedEffect(player) {
        while (true) {
            currentPosition = player?.currentPosition ?: 0L
            bufferedPosition = player?.bufferedPosition ?: 0L
            duration = player?.contentDuration?.coerceAtLeast(0L) ?: 0L
            kotlinx.coroutines.delay(500L)
        }
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val channelListItems by activity.viewModel.channelListItems.observeAsState(emptyList())
    val isChannelListAvailable = activity.contentType == PlayerActivity.ContentType.CHANNEL &&
        channelListItems.isNotEmpty() &&
        (isLandscape || com.livetvpro.app.utils.DeviceUtils.isTvDevice)

    val isPipSupported = !com.livetvpro.app.utils.DeviceUtils.isTvDevice &&
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else false

    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxSize()
    ) {
        if (!isLandscape) {
            val isNetworkStream = activity.contentType == PlayerActivity.ContentType.NETWORK_STREAM
            androidx.compose.foundation.layout.Box(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .padding(top = statusBarHeight)
                    .then(
                        if (isNetworkStream) androidx.compose.ui.Modifier.weight(1f)
                        else androidx.compose.ui.Modifier.aspectRatio(16f / 9f)
                    )
            ) {
                if (errorMessage.isNotBlank()) {
                    androidx.compose.foundation.layout.Box(
                        contentAlignment = androidx.compose.ui.Alignment.Center,
                        modifier = androidx.compose.ui.Modifier.fillMaxSize()
                    ) {
                        androidx.compose.material3.Text(
                            text = errorMessage,
                            color = androidx.compose.ui.graphics.Color.White,
                            fontFamily = androidx.compose.ui.text.font.FontFamily(
                                androidx.compose.ui.text.font.Font(com.livetvpro.app.R.font.bergen_sans)
                            ),
                            fontSize = 15.sp,
                            modifier = androidx.compose.ui.Modifier
                                .background(
                                    androidx.compose.ui.graphics.Color(0xFF1A1A1A),
                                    androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 24.dp, vertical = 10.dp)
                        )
                    }
                }
                com.livetvpro.app.ui.player.compose.PlayerControls(
                    state = controlsState,
                    isPlaying = isPlaying,
                    isMuted = isMuted,
                    currentPosition = currentPosition,
                    duration = duration,
                    bufferedPosition = bufferedPosition,
                    channelName = activity.contentName,
                    showPipButton = isPipSupported,
                    showAspectRatioButton = true,
                    isLandscape = false,
                    isTvMode = com.livetvpro.app.utils.DeviceUtils.isTvDevice,
                    centerControlsMode = preferencesManager.getCenterControlsMode(),
                    isNetworkStream = activity.contentType == PlayerActivity.ContentType.NETWORK_STREAM,
                    isChannelListAvailable = isChannelListAvailable,
                    onBackClick = { activity.finish() },
                    onPipClick = { activity.enterPipMode() },
                    onSettingsClick = { activity.showSettingsDialog() },
                    onMuteClick = { activity.toggleMute() },
                    onLockClick = { locked -> if (locked) controlsState.lock() else controlsState.unlock(scope) },
                    onChannelListClick = { showChannelList.value = true },
                    onPlayPauseClick = {
                        player?.let {
                            val hasError = activity.errorMessage.value.isNotBlank()
                            val hasEnded = it.playbackState == androidx.media3.common.Player.STATE_ENDED
                            if (hasError || hasEnded) activity.retryPlayback()
                            else if (it.isPlaying) it.pause() else it.play()
                        }
                    },
                    onSeek = { position -> player?.seekTo(position) },
                    onRewindClick = { player?.let { it.seekTo((it.currentPosition - activity.skipMs).coerceAtLeast(0L)) } },
                    onForwardClick = {
                        player?.let {
                            val newPos = it.currentPosition + activity.skipMs
                            if (it.isCurrentWindowLive && it.duration != androidx.media3.common.C.TIME_UNSET && newPos >= it.duration) it.seekTo(it.duration)
                            else it.seekTo(newPos)
                        }
                    },
                    onPrevClick = {
                        when (activity.contentType) {
                            PlayerActivity.ContentType.EVENT -> {
                                if (activity.allEventLinks.size > 1) {
                                    val prev = (activity.currentLinkIndex - 1).coerceAtLeast(0)
                                    if (prev != activity.currentLinkIndex) activity.switchToLink(activity.allEventLinks[prev], prev)
                                }
                            }
                            PlayerActivity.ContentType.CHANNEL -> {
                                val items = activity.viewModel.channelListItems.value
                                if (!items.isNullOrEmpty()) {
                                    val idx = items.indexOfFirst { it.id == activity.contentId }.takeIf { it != -1 } ?: 0
                                    val prev = (idx - 1).coerceAtLeast(0)
                                    if (prev != idx) activity.switchToChannel(items[prev])
                                }
                            }
                            else -> {}
                        }
                    },
                    onNextClick = {
                        when (activity.contentType) {
                            PlayerActivity.ContentType.EVENT -> {
                                if (activity.allEventLinks.size > 1) {
                                    val next = (activity.currentLinkIndex + 1).coerceAtMost(activity.allEventLinks.size - 1)
                                    if (next != activity.currentLinkIndex) activity.switchToLink(activity.allEventLinks[next], next)
                                }
                            }
                            PlayerActivity.ContentType.CHANNEL -> {
                                val items = activity.viewModel.channelListItems.value
                                if (!items.isNullOrEmpty()) {
                                    val idx = items.indexOfFirst { it.id == activity.contentId }.takeIf { it != -1 } ?: 0
                                    val next = (idx + 1).coerceAtMost(items.size - 1)
                                    if (next != idx) activity.switchToChannel(items[next])
                                }
                            }
                            else -> {}
                        }
                    },
                    onAspectRatioClick = { activity.cycleAspectRatio() },
                    onFullscreenClick = { activity.toggleFullscreen() },
                    onVolumeSwipe = { vol ->
                        activity.gestureVolume = vol
                        val am = activity.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (vol / 100f * am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)).toInt(), 0)
                    },
                    onBrightnessSwipe = { bri ->
                        activity.gestureBrightness = bri
                        val lp = activity.window.attributes
                        lp.screenBrightness = if (bri == 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else bri / 100f
                        activity.window.attributes = lp
                    },
                    initialVolume = activity.gestureVolume,
                    initialBrightness = activity.gestureBrightness,
                )
            }
        } else {
            androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize()) {
                com.livetvpro.app.ui.player.compose.PlayerControls(
                    state = controlsState,
                    isPlaying = isPlaying,
                    isMuted = isMuted,
                    currentPosition = currentPosition,
                    duration = duration,
                    bufferedPosition = bufferedPosition,
                    channelName = activity.contentName,
                    showPipButton = isPipSupported,
                    showAspectRatioButton = true,
                    isLandscape = true,
                    isTvMode = com.livetvpro.app.utils.DeviceUtils.isTvDevice,
                    centerControlsMode = preferencesManager.getCenterControlsMode(),
                    isNetworkStream = activity.contentType == PlayerActivity.ContentType.NETWORK_STREAM,
                    isChannelListAvailable = isChannelListAvailable,
                    onBackClick = { activity.finish() },
                    onPipClick = { activity.enterPipMode() },
                    onSettingsClick = { activity.showSettingsDialog() },
                    onMuteClick = { activity.toggleMute() },
                    onLockClick = { locked -> if (locked) controlsState.lock() else controlsState.unlock(scope) },
                    onChannelListClick = { showChannelList.value = true },
                    onPlayPauseClick = {
                        player?.let {
                            val hasError = activity.errorMessage.value.isNotBlank()
                            val hasEnded = it.playbackState == androidx.media3.common.Player.STATE_ENDED
                            if (hasError || hasEnded) activity.retryPlayback()
                            else if (it.isPlaying) it.pause() else it.play()
                        }
                    },
                    onSeek = { position -> player?.seekTo(position) },
                    onRewindClick = { player?.let { it.seekTo((it.currentPosition - activity.skipMs).coerceAtLeast(0L)) } },
                    onForwardClick = {
                        player?.let {
                            val newPos = it.currentPosition + activity.skipMs
                            if (it.isCurrentWindowLive && it.duration != androidx.media3.common.C.TIME_UNSET && newPos >= it.duration) it.seekTo(it.duration)
                            else it.seekTo(newPos)
                        }
                    },
                    onPrevClick = {
                        when (activity.contentType) {
                            PlayerActivity.ContentType.EVENT -> {
                                if (activity.allEventLinks.size > 1) {
                                    val prev = (activity.currentLinkIndex - 1).coerceAtLeast(0)
                                    if (prev != activity.currentLinkIndex) activity.switchToLink(activity.allEventLinks[prev], prev)
                                }
                            }
                            PlayerActivity.ContentType.CHANNEL -> {
                                val items = activity.viewModel.channelListItems.value
                                if (!items.isNullOrEmpty()) {
                                    val idx = items.indexOfFirst { it.id == activity.contentId }.takeIf { it != -1 } ?: 0
                                    val prev = (idx - 1).coerceAtLeast(0)
                                    if (prev != idx) activity.switchToChannel(items[prev])
                                }
                            }
                            else -> {}
                        }
                    },
                    onNextClick = {
                        when (activity.contentType) {
                            PlayerActivity.ContentType.EVENT -> {
                                if (activity.allEventLinks.size > 1) {
                                    val next = (activity.currentLinkIndex + 1).coerceAtMost(activity.allEventLinks.size - 1)
                                    if (next != activity.currentLinkIndex) activity.switchToLink(activity.allEventLinks[next], next)
                                }
                            }
                            PlayerActivity.ContentType.CHANNEL -> {
                                val items = activity.viewModel.channelListItems.value
                                if (!items.isNullOrEmpty()) {
                                    val idx = items.indexOfFirst { it.id == activity.contentId }.takeIf { it != -1 } ?: 0
                                    val next = (idx + 1).coerceAtMost(items.size - 1)
                                    if (next != idx) activity.switchToChannel(items[next])
                                }
                            }
                            else -> {}
                        }
                    },
                    onAspectRatioClick = { if (activity.contentType == PlayerActivity.ContentType.NETWORK_STREAM) activity.cycleAspectRatio() else activity.cycleAspectRatio() },
                    onFullscreenClick = { activity.toggleFullscreen() },
                    onVolumeSwipe = { vol ->
                        activity.gestureVolume = vol
                        val am = activity.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (vol / 100f * am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)).toInt(), 0)
                    },
                    onBrightnessSwipe = { bri ->
                        activity.gestureBrightness = bri
                        val lp = activity.window.attributes
                        lp.screenBrightness = if (bri == 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else bri / 100f
                        activity.window.attributes = lp
                    },
                    initialVolume = activity.gestureVolume,
                    initialBrightness = activity.gestureBrightness,
                )
                if (links.size > 1) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = controlsState.isVisible && !controlsState.isLocked,
                        enter = androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.fadeOut(),
                        modifier = androidx.compose.ui.Modifier
                            .align(androidx.compose.ui.Alignment.TopCenter)
                            .padding(top = 44.dp),
                    ) {
                        com.livetvpro.app.ui.player.compose.PlayerScreen(
                            isLandscape = true,
                            relatedContentState = com.livetvpro.app.ui.player.compose.RelatedContentState.Hidden,
                            links = links,
                            selectedLinkIndex = selectedLinkIndex,
                            messageBanner = "",
                            messageBannerUrl = "",
                            onLinkClick = onLinkClick,
                            onChannelClick = onChannelClick,
                            onEventClick = onEventClick,
                            onMessageBannerClick = onMessageBannerClick,
                            spanCount = spanCount,
                            eventSpanCount = eventSpanCount,
                        )
                    }
                }
            }
        }
        if (!isLandscape && activity.contentType != PlayerActivity.ContentType.NETWORK_STREAM) {
            com.livetvpro.app.ui.player.compose.PlayerScreen(
                isLandscape = false,
                relatedContentState = relatedContentState,
                links = links,
                selectedLinkIndex = selectedLinkIndex,
                messageBanner = messageBanner,
                messageBannerUrl = messageBannerUrl,
                onLinkClick = onLinkClick,
                onChannelClick = onChannelClick,
                onEventClick = onEventClick,
                onMessageBannerClick = onMessageBannerClick,
                spanCount = spanCount,
                eventSpanCount = eventSpanCount,
            )
        }
    }
    
    if (isLandscape && errorMessage.isNotBlank()) {
        androidx.compose.foundation.layout.Box(
            contentAlignment = androidx.compose.ui.Alignment.Center,
            modifier = androidx.compose.ui.Modifier.fillMaxSize()
        ) {
            androidx.compose.material3.Text(
                text = errorMessage,
                color = androidx.compose.ui.graphics.Color.White,
                fontFamily = androidx.compose.ui.text.font.FontFamily(
                    androidx.compose.ui.text.font.Font(com.livetvpro.app.R.font.bergen_sans)
                ),
                fontSize = 15.sp,
                modifier = androidx.compose.ui.Modifier
                    .background(
                        androidx.compose.ui.graphics.Color(0xFF1A1A1A),
                        androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 24.dp, vertical = 10.dp)
            )
        }
    }
    if (showSettingsDialog && player != null) {
        com.livetvpro.app.ui.player.settings.PlayerSettingsDialog(
            player = player,
            onDismiss = onSettingsDismiss,
        )
    }
    if (showFloatingDialog) {
        com.livetvpro.app.ui.player.dialogs.FloatingPlayerDialog(
            preferencesManager = preferencesManager,
            onDismiss = onFloatingDismiss,
        )
    }

}

private val Int.dp: androidx.compose.ui.unit.Dp get() = androidx.compose.ui.unit.Dp(this.toFloat())
private val Float.dp: androidx.compose.ui.unit.Dp get() = androidx.compose.ui.unit.Dp(this)
